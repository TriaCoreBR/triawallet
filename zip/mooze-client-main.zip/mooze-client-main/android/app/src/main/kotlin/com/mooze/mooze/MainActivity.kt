package com.mooze.mooze

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
