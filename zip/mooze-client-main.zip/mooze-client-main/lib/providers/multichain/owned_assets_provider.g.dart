// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'owned_assets_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$ownedAssetsNotifierHash() =>
    r'64d338059aaca3f3bdc882a1d112c234152b5249';

/// See also [OwnedAssetsNotifier].
@ProviderFor(OwnedAssetsNotifier)
final ownedAssetsNotifierProvider =
    AsyncNotifierProvider<OwnedAssetsNotifier, List<OwnedAsset>>.internal(
      OwnedAssetsNotifier.new,
      name: r'ownedAssetsNotifierProvider',
      debugGetCreateSourceHash:
          const bool.fromEnvironment('dart.vm.product')
              ? null
              : _$ownedAssetsNotifierHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$OwnedAssetsNotifier = AsyncNotifier<List<OwnedAsset>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
