// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wallet_sync_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$walletSyncServiceHash() => r'486a231d9306f83af0888a6bb9052b438bee2c0b';

/// See also [WalletSyncService].
@ProviderFor(WalletSyncService)
final walletSyncServiceProvider =
    NotifierProvider<WalletSyncService, AsyncValue<DateTime?>>.internal(
      WalletSyncService.new,
      name: r'walletSyncServiceProvider',
      debugGetCreateSourceHash:
          const bool.fromEnvironment('dart.vm.product')
              ? null
              : _$walletSyncServiceHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$WalletSyncService = Notifier<AsyncValue<DateTime?>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
