// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mnemonic_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$mnemonicNotifierHash() => r'2826be376c12a87d385fe125588d6bca543db26a';

/// See also [MnemonicNotifier].
@ProviderFor(MnemonicNotifier)
final mnemonicNotifierProvider =
    AutoDisposeAsyncNotifierProvider<MnemonicNotifier, String?>.internal(
      MnemonicNotifier.new,
      name: r'mnemonicNotifierProvider',
      debugGetCreateSourceHash:
          const bool.fromEnvironment('dart.vm.product')
              ? null
              : _$mnemonicNotifierHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$MnemonicNotifier = AutoDisposeAsyncNotifier<String?>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
