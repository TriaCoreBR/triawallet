enum Network { bitcoin, liquid }
